const express = require('express');
const router = express.Router();
const auth = require('../middlewares/auth');
const Resume = require('../models/Resume');

// Save resume
router.post('/', auth, async (req, res) => {
  try {
    const resumeData = req.body;
    const resume = new Resume({ ...resumeData, user: req.user.id });
    await resume.save();
    res.json(resume);
  } catch (err) {
    res.status(500).send('Server error');
  }
});

// Get user resumes
router.get('/', auth, async (req, res) => {
  try {
    const resumes = await Resume.find({ user: req.user.id });
    res.json(resumes);
  } catch (err) {
    res.status(500).send('Server error');
  }
});

module.exports = router;