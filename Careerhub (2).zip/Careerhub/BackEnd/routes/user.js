// routes/users.js
const express = require('express');
const router = express.Router();
const auth = require('../middlewares/auth');
const User = require('../models/user');

// Save resume
router.put('/resume', auth, async (req, res) => {
  try {
    const user = await User.findByIdAndUpdate(
      req.user.id,
      { resume: req.body },
      { new: true }
    );
    res.json(user.resume);
  } catch (err) {
    res.status(500).json({ message: 'Server error' });
  }
});

// Get saved jobs
router.get('/saved-jobs', auth, async (req, res) => {
  try {
    const user = await User.findById(req.user.id).populate('savedJobs');
    res.json(user.savedJobs);
  } catch (err) {
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;