// Add to script.js
const API_BASE_URL = 'http://localhost:6000/api'; // Update with your backend URL

// Enhanced authentication handling
document.addEventListener('DOMContentLoaded', function() {
    // ... existing modal code ...

    // Modified auth form submissions
    authForms.forEach(form => {
        form.addEventListener('submit', async function(e) {
            e.preventDefault();
            const formData = new FormData(form);
            const formEntries = Object.fromEntries(formData.entries());

            try {
                let response;
                if (form.classList.contains('login-form')) {
                    response = await fetch(`${API_BASE_URL}/auth/login`, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify(formEntries)
                    });
                } else {
                    response = await fetch(`${API_BASE_URL}/auth/register`, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify(formEntries)
                    });
                }

                const data = await response.json();
                if (!response.ok) throw new Error(data.message || 'Authentication failed');

                // Store user and token
                localStorage.setItem('user', JSON.stringify(data));
                localStorage.setItem('token', data.token);
                
                // Update UI
                document.querySelectorAll('.auth-buttons').forEach(container => {
                    container.innerHTML = `
                        <span class="user-greeting">Hello, ${data.name}!</span>
                        <button id="logout-btn">Logout</button>
                    `;
                });

                alert('Authentication successful!');
                loginModal.style.display = 'none';
                registerModal.style.display = 'none';
            } catch (error) {
                alert(error.message);
            }
        });
    });

    // Enhanced resume saving
    const saveResumeBtn = document.getElementById('save-resume');
    if (saveResumeBtn) {
        saveResumeBtn.addEventListener('click', async () => {
            const resumeData = collectResumeData();
            
            try {
                const response = await fetch(`${API_BASE_URL}/resumes`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${localStorage.getItem('token')}`
                    },
                    body: JSON.stringify(resumeData)
                });

                if (!response.ok) throw new Error('Failed to save resume');
                alert('Resume saved successfully!');
            } catch (error) {
                alert(error.message);
            }
        });
    }
});

// Helper function to collect resume data
function collectResumeData() {
    return {
        personalInfo: {
            firstName: document.getElementById('fullName').value,
            email: document.getElementById('email').value,
            phone: document.getElementById('phone').value,
            address: document.getElementById('address').value,
            summary: document.getElementById('objective').value,
            // Add other fields as needed
        },
        education: [],
        experience: [],
        skills: [],
        // Add other sections
    };
}

// Enhanced logout functionality
document.addEventListener('click', function(e) {
    if (e.target.id === 'logout-btn') {
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        window.location.href = 'index.html';
    }
});

// Load resume data when page loads
async function loadResumeData() {
    try {
        const response = await fetch(`${API_BASE_URL}/resumes`, {
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('token')}`
            }
        });
        
        if (!response.ok) throw new Error('Failed to load resume');
        const data = await response.json();
        populateResumeForm(data);
    } catch (error) {
        console.error('Error loading resume:', error);
    }
}

function populateResumeForm(data) {
    // Populate form fields with data
    document.getElementById('fullName').value = data.personalInfo.firstName || '';
    document.getElementById('email').value = data.personalInfo.email || '';
    // Populate other fields similarly
}

// Initialize resume data if on wizard page
if (window.location.pathname.includes('resume-wizard')) {
    loadResumeData();
}

// Add to initResumeWizard function
function initResumeWizard() {
    // ... existing code ...
    // Add authorization header to PDF generation
    function exportResumePDF() {
        const resumePreview = document.querySelector('.resume-preview');
        if (!resumePreview) return;

        // Add watermark with user info
        const user = JSON.parse(localStorage.getItem('user'));
        const watermark = document.createElement('div');
        watermark.style.position = 'absolute';
        watermark.style.bottom = '10px';
        watermark.style.right = '10px';
        watermark.style.color = '#ccc';
        watermark.textContent = `Generated by ${user?.name || 'Resume Builder Pro'}`;
        resumePreview.appendChild(watermark);

        // Generate PDF
        html2pdf().from(resumePreview).save();
        resumePreview.removeChild(watermark);
    }
}