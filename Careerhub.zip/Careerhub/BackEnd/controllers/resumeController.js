const Resume = require('../models/Resume');

exports.saveResume = async (req, res) => {
  try {
    const { personalInfo, education, experience, skills, projects, certifications } = req.body;
    
    let resume = await Resume.findOne({ user: req.user.id });
    
    if (resume) {
      resume = await Resume.findByIdAndUpdate(
        resume._id,
        { $set: { personalInfo, education, experience, skills, projects, certifications } },
        { new: true }
      );
      return res.json(resume);
    }

    resume = new Resume({
      user: req.user.id,
      personalInfo,
      education,
      experience,
      skills,
      projects,
      certifications
    });

    await resume.save();
    res.json(resume);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
};

exports.getResume = async (req, res) => {
  try {
    const resume = await Resume.findOne({ user: req.user.id });
    if (!resume) return res.status(404).json({ msg: 'Resume not found' });
    res.json(resume);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
};