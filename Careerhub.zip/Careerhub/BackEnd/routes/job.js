const express = require('express');
const router = express.Router();
const Job = require('../models/job');

// Get all jobs
router.get('/', async (req, res) => {
  try {
    const jobs = await Job.find().sort('-createdAt');
    res.json(jobs);
  } catch (err) {
    res.status(500).send('Server error');
  }
});

// Post new job
router.post('/', async (req, res) => {
  try {
    const jobData = req.body;
    const job = new Job(jobData);
    await job.save();
    res.json(job);
  } catch (err) {
    res.status(500).send('Server error');
  }
});

module.exports = router;